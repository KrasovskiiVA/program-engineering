//---------------------------------------------------------------------------

#ifndef dmuH
#define dmuH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Data.DB.hpp>
#include <FireDAC.Comp.Client.hpp>
#include <FireDAC.Comp.DataSet.hpp>
#include <FireDAC.DApt.hpp>
#include <FireDAC.DApt.Intf.hpp>
#include <FireDAC.DatS.hpp>
#include <FireDAC.FMXUI.Wait.hpp>
#include <FireDAC.Phys.hpp>
#include <FireDAC.Phys.Intf.hpp>
#include <FireDAC.Phys.SQLite.hpp>
#include <FireDAC.Phys.SQLiteDef.hpp>
#include <FireDAC.Stan.Async.hpp>
#include <FireDAC.Stan.Def.hpp>
#include <FireDAC.Stan.Error.hpp>
#include <FireDAC.Stan.ExprFuncs.hpp>
#include <FireDAC.Stan.Intf.hpp>
#include <FireDAC.Stan.Option.hpp>
#include <FireDAC.Stan.Param.hpp>
#include <FireDAC.Stan.Pool.hpp>
#include <FireDAC.UI.Intf.hpp>
#include <FireDAC.Comp.UI.hpp>
//---------------------------------------------------------------------------
class Tdm : public TDataModule
{
__published:	// IDE-managed Components
	TFDConnection *connection;
	TFDTable *worker;
	TFDTable *client;
	TFDTable *list;
	TFDTable *rooms;
	TFDTable *sex;
	TFDTable *status;
	TFDGUIxWaitCursor *FDGUIxWaitCursor1;
	TFDAutoIncField *workerid;
	TStringField *workerFIO;
	TFDAutoIncField *clientid;
	TStringField *clientfname;
	TStringField *clientlname;
	TStringField *clientmname;
	TDateField *clientbirth;
	TIntegerField *clientsexID;
	TStringField *clientpserie;
	TStringField *clientpnumber;
	TStringField *clientpinfo1;
	TStringField *clientpinfo2;
	TStringField *clientphone;
	TFDAutoIncField *listid;
	TIntegerField *listworkerID;
	TIntegerField *listclientID;
	TIntegerField *listnum;
	TIntegerField *listfullPrice;
	TFDAutoIncField *roomsid;
	TIntegerField *roomsfloor;
	TIntegerField *roomsnumber;
	TIntegerField *roomsstatusID;
	TIntegerField *roomsroomsN;
	TFDAutoIncField *sexid;
	TStringField *sexname;
	TFDAutoIncField *statusid;
	TStringField *statusname;
	TIntegerField *statuscost;
	TStringField *clientsex;
	TStringField *listWorker;
	TStringField *listFName;
	TStringField *listLName;
	TStringField *roomsstatus;
	TIntegerField *roomscost;
	TFDQuery *query;
	TIntegerField *listroomID;
	TDateTimeField *listDateToIn;
	TDateTimeField *listDateToOut;
	TIntegerField *listRoomN;
	void __fastcall connectionAfterConnect(TObject *Sender);
	void __fastcall connectionBeforeConnect(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall Tdm(TComponent* Owner);
    void connect();
};
//---------------------------------------------------------------------------
extern PACKAGE Tdm *dm;
//---------------------------------------------------------------------------
#endif
