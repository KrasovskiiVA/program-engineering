﻿// ---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "fmu.h"
// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "FMX.frxClass"
#pragma link "FMX.frxDBSet"
#pragma link "FMX.frxFMX"
#pragma link "FMX.frxPreview"
#pragma resource "*.fmx"
Tfm *fm;

// ---------------------------------------------------------------------------
// Инициализация переменных в конструкторе
__fastcall Tfm::Tfm(TComponent* Owner) : TForm(Owner) {
	chose = 0;
	choseID = -1;
}
// ---------------------------------------------------------------------------
// Переход на вкладку добавления сотрудника и создание новой пустой записи
void __fastcall Tfm::buWAddClick(TObject *Sender) {
	dm->worker->Append();
	tcWorker->ActiveTab = workerEdit;
}
// ---------------------------------------------------------------------------
// Переход на редактирование сотрудника и открытия доступа к редактированию
void __fastcall Tfm::buWEditClick(TObject *Sender) {
	dm->worker->Edit();
	tcWorker->ActiveTab = workerEdit;
}
// ---------------------------------------------------------------------------
// Удаление сотрудника с запросом на подтверждение
void __fastcall Tfm::buWDeleteClick(TObject *Sender) {
	if (MessageDlg(L"Вы действительно хотите удалить?", TMsgDlgType::mtWarning,
		TMsgDlgButtons() << TMsgDlgBtn::mbYes << TMsgDlgBtn::mbNo, 0) == mrYes)
	{
		dm->worker->Delete();
	}

}
// ---------------------------------------------------------------------------
// Сохранить введенные данные о сотруднике
void __fastcall Tfm::buWSaveClick(TObject *Sender) {
	dm->worker->Post();
	tcWorker->ActiveTab = workerView;
}
// ---------------------------------------------------------------------------
// Отменить внесенные изменения в запись о сотруднике
void __fastcall Tfm::buWCancelClick(TObject *Sender) {
	dm->worker->Cancel();
	tcWorker->ActiveTab = workerView;
}
// ---------------------------------------------------------------------------
// Подготовка формы к выводу
void __fastcall Tfm::FormShow(TObject *Sender) {
	dm->connect();

	tc->TabPosition = TTabPosition::None;
	tc->ActiveTab = log;

	tcWorker->TabPosition = TTabPosition::None;
	tcWorker->ActiveTab = workerView;

	tcClient->TabPosition = TTabPosition::None;
	tcClient->ActiveTab = clientView;

	tcList->TabPosition = TTabPosition::None;
	tcList->ActiveTab = lView;
	initGrid(3, 3);
}
// ---------------------------------------------------------------------------
// Переход на вкладку добавления клиента и создание новой пустой записи
void __fastcall Tfm::buCaddClick(TObject *Sender) {
	dm->client->Append();
	tcClient->ActiveTab = clientEdit;
}
// ---------------------------------------------------------------------------
// Переход на редактирование клиента и открытия доступа к редактированию
void __fastcall Tfm::buCEditClick(TObject *Sender) {
	dm->sex->Locate("id", dm->client->FieldByName("sexID")->AsInteger);
	dm->client->Edit();
	tcClient->ActiveTab = clientEdit;
}
// ---------------------------------------------------------------------------
// Удаление клиента с запросом на подтверждение
void __fastcall Tfm::buCDeleteClick(TObject *Sender) {
	if (MessageDlg(L"Вы действительно хотите удалить данные о клиенте?",
		TMsgDlgType::mtWarning,
		TMsgDlgButtons() << TMsgDlgBtn::mbYes << TMsgDlgBtn::mbNo, 0) == mrYes)
	{
		dm->client->Delete();
	}
}
// ---------------------------------------------------------------------------
// Сохранить введенные данные о клиенте
void __fastcall Tfm::Button1Click(TObject *Sender) {
	dm->client->FieldByName("sexID")->AsInteger =
		dm->sex->FieldByName("id")->AsInteger;
	dm->client->Post();
	tcClient->ActiveTab = clientView;
}
// ---------------------------------------------------------------------------
// Отменить внесенные изменения в запись о клиенте
void __fastcall Tfm::Button3Click(TObject *Sender) {
	dm->client->Cancel();
	tcClient->ActiveTab = clientView;
}
// -------------------------------------------------------------------------
// Построение сетки
// Создание необходимого количества ячеек для хранения всех номеров отеля
// Присваивание кнопкам события при нажатие
void Tfm::initGrid(int rows_, int cols_) {

	cols = rows_;
	rows = rows_;

	// Удалить всё
	grid->ControlCollection->Clear();
	grid->ColumnCollection->Clear();
	grid->RowCollection->Clear();
	grid->ExpandStyle = TGridPanelLayout::TExpandStyle::FixedSize;

	// Размер элемента = размерГрида  / кол-во элементов
	int elementWidth = grid->Width / cols;
	int elementHeight = grid->Height / rows;

	// Размер колонок
	for (int i = 0; i < cols; ++i) {
		grid->ColumnCollection->Add();
		grid->ColumnCollection->Items[i]->SizeStyle =
			TGridPanelLayout::TSizeStyle::Absolute;
		grid->ColumnCollection->Items[i]->Value = elementWidth;
	}
	// Размер строк
	for (int i = 0; i < rows; ++i) {
		grid->RowCollection->Add();
		grid->RowCollection->Items[i]->SizeStyle =
			TGridPanelLayout::TSizeStyle::Absolute;
		grid->RowCollection->Items[i]->Value = elementHeight;
	}
	rooms.resize(cols * rows);
	labels.resize(cols * rows);
	btns.resize(cols * rows);

	TAlphaColor colors[] = {claGreen, claBlue, claBlack};
	for (int i = 0; i < cols * rows; ++i) {

		rooms[i] = new TLayout(grid);

		btns[i] = new TButton(rooms[i]);
		btns[i]->Parent = rooms[i];
		btns[i]->Text = L"Комната: " + IntToStr((int)dm->rooms->Lookup("id",
			i + 1, "number"));

		labels[i] = new TLabel(rooms[i]);
		labels[i]->Parent = rooms[i];

		int id = dm->rooms->Lookup("id", i + 1, "statusID");
		costs[i] = dm->status->Lookup("id", id, "cost");

		int numRooms = dm->rooms->Lookup("id", i + 1, "roomsN");

		labels[i]->Text = dm->status->Lookup("id", id, "name");
		labels[i]->Text += L"  Стоимость : " + IntToStr(costs[i]);
		labels[i]->Text += L"  Комнат : " + IntToStr(numRooms);

	

		labels[i]->TextSettings->FontColor = colors[id - 1];

		btns[i]->Align = TAlignLayout::Top;
		btns[i]->Height = elementHeight / 2;
		btns[i]->OnClick = clickEvent;
		btns[i]->Tag = i + 1;
		labels[i]->Align = TAlignLayout::Client;

		rooms[i]->Parent = grid;
		rooms[i]->Align = TAlignLayout::Client;
		grid->ControlCollection->AddControl(rooms[i]);

	}
}
// Вернуть кнопки в исходное состояние
void Tfm::resetButtons() {
	for (int i = 0; i < rows * cols; ++i) {
		rooms[i]->Enabled = true;
	}
}
// Событие при выборе номера отеля
void __fastcall Tfm::clickEvent(TObject *Sender) {

	choseID = ((TComponent*)Sender)->Tag;
	int statusId = dm->rooms->Lookup("id", choseID, "statusID");
	chose = dm->status->Lookup("id", statusId, "cost");
	edListCost->Text = chose * days;
}
// Запрос на проверку занятности номеров по выбранным датам
void Tfm::query() {
dm->query->Close();
	resetButtons();

	UnicodeString UIN = FormatDateTime("yyyy-mm-dd", dateIN->Date);
	UnicodeString UOUT = FormatDateTime("yyyy-mm-dd", dateOUT->Date);

	//UIN = StringReplace(UIN, ".", "-", TReplaceFlags()<<rfReplaceAll);

	//UOUT = StringReplace(UOUT, ".", "-", TReplaceFlags()<<rfReplaceAll);

	dm->query->SQL->Text = "SELECT roomID FROM List WHERE (DateToIn <= '" + UIN +
	 "' AND DateToOut >= '" + UIN + "') OR (DateToIn <= '" + UOUT +
	 "' AND DateToOut >= '" + UOUT + "') OR (DateToIn > '" + UIN + "' AND DateToOut < '" + UOUT + "');";
	//ShowMessage(dm->query->SQL->Text);
	dm->query->Open();

	dm->query->First();
	while (!dm->query->Eof) {

		int id = dm->query->FieldByName("roomID")->AsInteger;
	   // ShowMessage(id);
		for (int i = 0; i < rows * cols; ++i) {
			if (id == btns[i]->Tag) {
				rooms[i]->Enabled = false;
			}
		}

		dm->query->Next();
	}
}
// Событие при выборе даты приезда
void __fastcall Tfm::dateINChange(TObject *Sender) {
	edDateIN->Date = dateIN->Date;

	days = int(dateOUT->Date - dateIN->Date);
	edListDays->Text = days;
	edListCost->Text = chose * days;
	query();
}
// ---------------------------------------------------------------------------
// Событие при выборе даты отъезда
void __fastcall Tfm::dateOUTChange(TObject *Sender) {
	edDateOUT->Date = dateOUT->Date;

	days = int(dateOUT->Date - dateIN->Date);
	edListDays->Text = days;
	edListCost->Text = chose * days;
    query();
}
// ---------------------------------------------------------------------------
// Подтверждения бронирования номера с проверкой на ошибки
void __fastcall Tfm::Button6Click(TObject *Sender) {
	if (edListNum->Text == "") {
		ShowMessage(L"Введите количество человек");
		return;
	}
	if (choseID == -1) {
		ShowMessage(L"Комната не выбрана");
		return;
	}

	dm->list->Append();
	dm->list->FieldByName("workerID")->AsInteger = workerId;
	dm->list->FieldByName("clientID")->AsInteger =
		dm->client->FieldByName("id")->AsInteger;
	dm->list->FieldByName("num")->AsInteger = StrToInt(edListNum->Text);
	dm->list->FieldByName("DateToIn")->AsDateTime = dateIN->Date;
	dm->list->FieldByName("DateToOut")->AsDateTime = dateOUT->Date;
	dm->list->FieldByName("roomID")->AsInteger = choseID;
	dm->list->FieldByName("fullPrice")->AsInteger = StrToInt(edListCost->Text);
	dm->list->Post();
}
// ---------------------------------------------------------------------------
// Возврат в меню
void __fastcall Tfm::buLogClick(TObject *Sender) {
	workerId = dm->worker->FieldByName("id")->AsInteger;
	tc->ActiveTab = menu;
}
// ---------------------------------------------------------------------------
// Список бронированных номеров
void __fastcall Tfm::Button7Click(TObject *Sender)
{
	tcList->ActiveTab = lView;
}
//---------------------------------------------------------------------------
// Возврат к авторизации
void __fastcall Tfm::Button8Click(TObject *Sender)
{
	tc->ActiveTab = log;
}
//---------------------------------------------------------------------------
// Переход на вкладку по работе с клиентами
void __fastcall Tfm::Button9Click(TObject *Sender)
{
    	tc->ActiveTab = client;
}
//---------------------------------------------------------------------------
// Переход на вкадку по работе с сотрудниками
void __fastcall Tfm::Button10Click(TObject *Sender)
{
	tc->ActiveTab = worker;
}
//---------------------------------------------------------------------------
// Переход на вкладку бронирования
void __fastcall Tfm::Button11Click(TObject *Sender)
{
	tc->ActiveTab = list;
}
//---------------------------------------------------------------------------
// Возврат к главному меню
void __fastcall Tfm::Button12Click(TObject *Sender)
{
    tc->ActiveTab = menu;
}
//---------------------------------------------------------------------------
// Бронирование
void __fastcall Tfm::Button2Click(TObject *Sender)
{
	tcList->ActiveTab = lEdit;
}
//---------------------------------------------------------------------------
// Просмотр отчета
void __fastcall Tfm::Button4Click(TObject *Sender)
{
	frxReport1->ShowReport();
}
//---------------------------------------------------------------------------

