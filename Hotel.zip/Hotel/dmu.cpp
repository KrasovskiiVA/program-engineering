//---------------------------------------------------------------------------


#pragma hdrstop

#include "dmu.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma classgroup "FMX.Controls.TControl"
#pragma resource "*.dfm"
Tdm *dm;
//---------------------------------------------------------------------------
__fastcall Tdm::Tdm(TComponent* Owner)
	: TDataModule(Owner)
{
}
//---------------------------------------------------------------------------
// Подключение к базе данных SQLite
void Tdm::connect()
{
	connection->Connected = true;
}
// Активация запросов к таблицам
void __fastcall Tdm::connectionAfterConnect(TObject *Sender)
{
	worker->Open();
	list->Open();
	rooms->Open();
	sex->Open();
	status->Open();
    client->Open();
}
//---------------------------------------------------------------------------
// Путь к файлу бд
void __fastcall Tdm::connectionBeforeConnect(TObject *Sender)
{
	connection->Params->Values["Database"] = "hotel.db";
}
//---------------------------------------------------------------------------

