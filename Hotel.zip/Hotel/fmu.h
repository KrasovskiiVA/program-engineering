// ---------------------------------------------------------------------------

#ifndef fmuH
#define fmuH
// ---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.ListView.Adapters.Base.hpp>
#include <FMX.ListView.Appearances.hpp>
#include <FMX.ListView.hpp>
#include <FMX.ListView.Types.hpp>
#include <FMX.StdCtrls.hpp>
#include <FMX.TabControl.hpp>
#include <FMX.Types.hpp>
#include "dmu.h"
#include <Data.Bind.Components.hpp>
#include <Data.Bind.DBScope.hpp>
#include <Data.Bind.EngExt.hpp>
#include <Fmx.Bind.DBEngExt.hpp>
#include <Fmx.Bind.Editors.hpp>
#include <System.Bindings.Outputs.hpp>
#include <System.Rtti.hpp>
#include <FMX.Layouts.hpp>
#include <FMX.Edit.hpp>
#include <FMX.ListBox.hpp>
#include <Data.Bind.Grid.hpp>
#include <Fmx.Bind.Grid.hpp>
#include <FMX.Grid.hpp>
#include <FMX.Grid.Style.hpp>
#include <FMX.ScrollBox.hpp>
#include <FMX.DateTimeCtrls.hpp>
#include <FMX.Memo.hpp>
#include <FMX.Calendar.hpp>
#include "FMX.frxClass.hpp"
#include "FMX.frxDBSet.hpp"
#include <vector>
using std::vector;

// ---------------------------------------------------------------------------
class Tfm : public TForm {
__published: // IDE-managed Components
	TToolBar *ToolBar1;
	TToolBar *ToolBar2;
	TTabControl *tc;
	TTabItem *log;
	TTabItem *menu;
	TTabItem *client;
	TTabItem *worker;
	TTabItem *list;
	TListView *ListView1;
	TBindSourceDB *BindSourceDB1;
	TBindingsList *BindingsList1;
	TLinkListControlToField *LinkListControlToField1;
	TTabControl *tcWorker;
	TTabItem *workerView;
	TTabItem *workerEdit;
	TLayout *Layout1;
	TButton *buWAdd;
	TButton *buWDelete;
	TButton *buWEdit;
	TEdit *edWorker;
	TLabel *Label1;
	TLayout *Layout2;
	TButton *buWSave;
	TButton *buWCancel;
	TLinkControlToField *LinkControlToField1;
	TComboBox *cbWorker;
	TLabel *Label2;
	TLayout *Layout3;
	TLayout *Layout4;
	TButton *buLog;
	TLinkListControlToField *LinkListControlToField2;
	TLabel *Label3;
	TTabControl *tcClient;
	TTabItem *clientView;
	TTabItem *clientEdit;
	TLayout *Layout5;
	TButton *buCadd;
	TButton *buCDelete;
	TButton *buCEdit;
	TGrid *gridClient;
	TBindSourceDB *BindSourceDB2;
	TLinkGridToDataSource *LinkGridToDataSourceBindSourceDB2;
	TGridPanelLayout *GridPanelLayout1;
	TLayout *Layout6;
	TButton *Button1;
	TButton *Button3;
	TLabel *Label4;
	TEdit *Edit1;
	TLabel *Label5;
	TEdit *Edit2;
	TLabel *Label6;
	TEdit *Edit3;
	TLabel *Label7;
	TDateEdit *DateEdit1;
	TLabel *Label8;
	TComboBox *cbCSex;
	TLabel *Label44;
	TEdit *Edit4;
	TLabel *Label10;
	TEdit *Edit5;
	TLabel *Label11;
	TEdit *Edit6;
	TGridPanelLayout *GridPanelLayout2;
	TLabel *Label12;
	TMemo *Memo1;
	TLabel *Label13;
	TMemo *Memo2;
	TLinkControlToField *LinkControlToField2;
	TLinkControlToField *LinkControlToField3;
	TLinkControlToField *LinkControlToField4;
	TLinkControlToField *LinkControlToField5;
	TBindSourceDB *BindSourceDB3;
	TLinkListControlToField *LinkListControlToField3;
	TLinkControlToField *LinkControlToField6;
	TLinkControlToField *LinkControlToField7;
	TLinkControlToField *LinkControlToField8;
	TLinkControlToField *LinkControlToField9;
	TLinkControlToField *LinkControlToField10;
	TTabControl *tcList;
	TTabItem *lView;
	TLayout *Layout7;
	TButton *Button2;
	TGrid *Grid1;
	TTabItem *lEdit;
	TLayout *Layout8;
	TButton *Button6;
	TButton *Button7;
	TCalendar *dateIN;
	TCalendar *dateOUT;
	TLabel *Label9;
	TLabel *Label14;
	TGridPanelLayout *grid;
	TDateEdit *edDateIN;
	TDateEdit *edDateOUT;
	TEdit *edListDays;
	TEdit *edListNum;
	TEdit *edListCost;
	TGridPanelLayout *GridPanelLayout3;
	TLabel *Label15;
	TLabel *lbl16;
	TLabel *Label17;
	TLabel *Label18;
	TLabel *Label19;
	TLayout *Layout9;
	TLayout *La;
	TLayout *Layout10;
	TLayout *Layout11;
	TBindSourceDB *BindSourceDB4;
	TLinkGridToDataSource *LinkGridToDataSourceBindSourceDB4;
	TButton *Button8;
	TButton *Button9;
	TButton *Button10;
	TButton *Button11;
	TButton *Button12;
	TButton *Button13;
	TButton *Button15;
	TLabel *Label20;
	TLabel *Label21;
	TLabel *Label16;
	TLayout *Layout12;
	TLayout *Layout13;
	TButton *Button4;
	TfrxDBDataset *frxDBDataset1;
	TfrxReport *frxReport1;

	void __fastcall buWAddClick(TObject *Sender);
	void __fastcall buWEditClick(TObject *Sender);
	void __fastcall buWDeleteClick(TObject *Sender);
	void __fastcall buWSaveClick(TObject *Sender);
	void __fastcall buWCancelClick(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall buCaddClick(TObject *Sender);
	void __fastcall buCEditClick(TObject *Sender);
	void __fastcall buCDeleteClick(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall dateINChange(TObject *Sender);
	void __fastcall dateOUTChange(TObject *Sender);
	void __fastcall Button6Click(TObject *Sender);
	void __fastcall buLogClick(TObject *Sender);
	void __fastcall Button7Click(TObject *Sender);
	void __fastcall Button8Click(TObject *Sender);
	void __fastcall Button9Click(TObject *Sender);
	void __fastcall Button10Click(TObject *Sender);
	void __fastcall Button11Click(TObject *Sender);
	void __fastcall Button12Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button4Click(TObject *Sender);

private: // User declarations
public: // User declarations
	__fastcall Tfm(TComponent* Owner);
	vector <TLayout* > rooms;
	vector <TButton* > btns;
	vector <TLabel* > labels;
	int costs[9];

	int rows;
	int cols;
	void __fastcall clickEvent(TObject *Sender);
	void initGrid(int rows_, int cols_);
	void resetButtons();
	int chose;
	int days;
	int choseID;
	void query();
	int workerId;
};

// ---------------------------------------------------------------------------
extern PACKAGE Tfm *fm;
// ---------------------------------------------------------------------------
#endif
